import numpy as np
import os

class RobotDataset:
    def __init__(self):
        self.data = []
        self.labels = []
        
    def create_training_dataset(self):
        """Generate training dataset based on expert behavioral rules"""
        print("Creating training dataset...")
        
        # Generate comprehensive training examples covering all scenarios
        for battery in np.arange(10, 101, 10):  # Battery levels from 10% to 100%
            for station_visible in [0, 1]:      # Charging station visible or not
                for obstacles in np.arange(0, 1.1, 0.2):  # Obstacle proximity from 0 to 1.0
                    for exploration_time in np.arange(0, 1.1, 0.2):  # Exploration time from 0 to 1.0
                        
                        # Define expert behavior rules for training
                        if battery > 70:
                            target = [1, 0, 0]  # Fast exploration mode
                        elif battery > 40:
                            target = [0, 1, 0]  # Medium exploration mode
                        elif battery > 25 and station_visible == 0:
                            target = [0, 0, 1]  # Charge mode - station not visible
                        elif battery <= 25:
                            target = [0, 0, 1]  # Charge mode - low battery
                        else:
                            target = [0, 1, 0]  # Default to medium exploration
                        
                        # Normalize inputs for neural network
                        inputs = [battery/100.0, station_visible, obstacles, exploration_time]
                        self.data.append(inputs)
                        self.labels.append(target)
        
        # Convert to numpy arrays for efficient processing
        self.data = np.array(self.data)
        self.labels = np.array(self.labels)
        
        print(f"Created {len(self.data)} training examples")
        return self.data, self.labels
    
    def save_dataset(self, filename="trained_model/robot_dataset.npz"):
        """Save the generated dataset to file for later use"""
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        np.savez(filename, data=self.data, labels=self.labels)
        print(f"Dataset saved to {filename}")
    
    def load_dataset(self, filename="trained_model/robot_dataset.npz"):
        """Load existing dataset from file"""
        if os.path.exists(filename):
            loaded_data = np.load(filename)
            self.data = loaded_data['data']
            self.labels = loaded_data['labels']
            print(f"Dataset loaded from {filename}")
            print(f"Loaded {len(self.data)} training examples")
            return self.data, self.labels
        else:
            print("Dataset file not found. Creating new dataset...")
            return self.create_training_dataset()

# Execute dataset creation when run as main script
if __name__ == "__main__":
    dataset = RobotDataset()
    data, labels = dataset.create_training_dataset()
    dataset.save_dataset()
    print("Dataset creation completed successfully")