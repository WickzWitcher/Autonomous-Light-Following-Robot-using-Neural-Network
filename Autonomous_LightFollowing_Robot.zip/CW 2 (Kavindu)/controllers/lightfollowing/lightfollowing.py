from controller import Robot
import cv2
import numpy as np
import os

class NeuralNetworkController:
    def __init__(self):
        # Network architecture matching training configuration
        self.input_size = 4
        self.hidden_size = 8
        self.output_size = 3
        
        # Load pre-trained model weights
        self.load_weights("C:\Users\KAVINDU\OneDrive\Desktop\CW 2 (Kavindu)\controllers\lightfollowing\trained_model")
    
    def sigmoid(self, x):
        """Sigmoid activation function"""
        return 1 / (1 + np.exp(-np.clip(x, -10, 10)))
    
    def softmax(self, x):
        """Softmax activation for decision output"""
        exp_x = np.exp(x - np.max(x))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    
    def load_weights(self, filename):
        """Load pre-trained neural network weights"""
        if os.path.exists(filename):
            loaded_weights = np.load(filename)
            self.weights1 = loaded_weights['weights1']
            self.weights2 = loaded_weights['weights2']
            self.bias1 = loaded_weights['bias1']
            self.bias2 = loaded_weights['bias2']
            print(f"Pre-trained model loaded from {filename}")
        else:
            raise FileNotFoundError(f"Trained model not found at {filename}. Please run training first.")
    
    def predict(self, inputs, battery_level):
        """Make behavior decision using neural network with battery level override"""
        X = np.array(inputs).reshape(1, -1)
        
        # Neural network forward pass
        layer1 = self.sigmoid(np.dot(X, self.weights1) + self.bias1)
        prediction = self.softmax(np.dot(layer1, self.weights2) + self.bias2)[0]
        
        # Convert probabilities to behavior decision with battery level override
        if battery_level > 70:
            decision = 'FAST'
        elif battery_level > 40:
            decision = 'MEDIUM'
        else:  # 40% and below
            decision = 'CHARGE'
        
        return decision, prediction

def main():
    # Simulation parameters
    TIME_STEP = 64
    MAX_SPEED = 6.28
    
    # Battery management parameters
    BATTERY_DECAY = 0.015
    battery_level = 100.0
    charging = False
    
    # Sensor thresholds
    OBSTACLE_THRESHOLD = 100.0
    DOCKING_DISTANCE = 300.0
    
    # Controller tuning
    Kp_turn = 0.008
    
    # Initialize robot
    robot = Robot()
    
    # Configure sensors
    ps = [robot.getDevice(f'ps{i}') for i in range(8)]
    for sensor in ps:
        sensor.enable(TIME_STEP)
    
    # Configure motors
    left_motor = robot.getDevice("left wheel motor")
    right_motor = robot.getDevice("right wheel motor")
    left_motor.setPosition(float('inf'))
    right_motor.setPosition(float('inf'))
    left_motor.setVelocity(0.0)
    right_motor.setVelocity(0.0)
    
    # Configure camera
    camera = robot.getDevice("camera")
    camera.enable(TIME_STEP)
    width = camera.getWidth()
    height = camera.getHeight()
    
    # Vision processing setup
    kernel = np.ones((5, 5), np.uint8)
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])
    
    # Obstacle avoidance weights
    weights = [
        [-1.0, -0.8], [-1.0, -0.8], [-0.4, 0.4], [0.0, 0.0],
        [0.0, 0.0], [0.4, -0.4], [-0.8, -1.0], [-0.8, -1.0]
    ]
    
    # Load neural network controller
    print("Loading neural network controller...")
    try:
        nn = NeuralNetworkController()
        print("Neural network controller ready")
    except Exception as e:
        print(f"Error: {e}")
        return
    
    exploration_time = 0
    
    # Setup camera display
    cv2.namedWindow("Camera", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Camera", 600, 450)
    
    print("Neural Network Controller Initialized")
    print("Starting robot operation...")
    
    # Main control loop
    while robot.step(TIME_STEP) != -1:
        # Battery management
        if charging:
            battery_level += 0.5
            if battery_level >= 100.0:
                battery_level = 100.0
                charging = False
                exploration_time = 0
                print("Battery fully charged. Resuming operation.")
        else:
            battery_level -= BATTERY_DECAY

        # Read sensor data
        ps_values = [s.getValue() for s in ps]
        
        # Process camera image
        image = camera.getImage()
        img_array = np.frombuffer(image, np.uint8).reshape((height, width, 4))
        frame = cv2.cvtColor(img_array, cv2.COLOR_BGRA2BGR)
        
        # Detect charging station
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Prepare neural network inputs
        exploration_time += TIME_STEP / 1000.0
        station_visible = 1.0 if contours else 0.0
        obstacles_near = min(max(ps_values[0], ps_values[7]) / 1000.0, 1.0)
        battery_norm = battery_level / 100.0
        exploration_norm = min(exploration_time / 60.0, 1.0)
        
        nn_inputs = [battery_norm, station_visible, obstacles_near, exploration_norm]
        
        # Get behavior decision from neural network with battery level
        decision, probabilities = nn.predict(nn_inputs, battery_level)
        
        # Set movement speed based on decision
        if decision == 'FAST':
            base_speed = MAX_SPEED * 1.0
        elif decision == 'MEDIUM':
            base_speed = MAX_SPEED * 0.9
        else:  # CHARGE
            base_speed = MAX_SPEED * 0.8

        # Display current status
        print(f"Battery: {battery_level:.1f}% | Decision: {decision} | Speed: {base_speed:.2f}")

        # Initialize motor speeds
        left_speed = base_speed
        right_speed = base_speed

        # Execute behavior decision
        if charging:
            left_speed, right_speed = 0, 0
            print("Charging in progress...")
        
        elif decision == 'CHARGE':
            print("Seeking charging station...")
            
            if contours:
                c = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(c)
                (x, y, w, h) = cv2.boundingRect(c)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 255), 2)
                
                # Approach station with proportional control
                cx = x + w // 2
                error = cx - (width / 2)
                turn_adjustment = Kp_turn * error
                
                approach_speed = np.clip(base_speed * (1 - (area / (width * height * 0.35))), 2.0, base_speed)
                left_speed = approach_speed - turn_adjustment
                right_speed = approach_speed + turn_adjustment

                front_obstacle_value = max(ps_values[0], ps_values[7])
                if front_obstacle_value > DOCKING_DISTANCE:
                    charging = True
                    left_speed, right_speed = 0, 0
                    print("Docked at charging station")
            
            else:
                # Search for station
                for i in range(8):
                    left_speed += weights[i][0] * (ps_values[i] / OBSTACLE_THRESHOLD)
                    right_speed += weights[i][1] * (ps_values[i] / OBSTACLE_THRESHOLD)
                
        else:
            # Exploration with obstacle avoidance
            for i in range(8):
                left_speed += weights[i][0] * (ps_values[i] / OBSTACLE_THRESHOLD)
                right_speed += weights[i][1] * (ps_values[i] / OBSTACLE_THRESHOLD)

        # Apply motor control
        left_speed = np.clip(left_speed, -base_speed, base_speed)
        right_speed = np.clip(right_speed, -base_speed, base_speed)
        left_motor.setVelocity(left_speed)
        right_motor.setVelocity(right_speed)

        # Update display
        display_frame = frame.copy()
        status = "CHG" if charging else decision
        cv2.putText(display_frame, f"{status}", (10, 25), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(display_frame, f"Batt:{battery_level:.0f}%", (10, 45), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        cv2.imshow("Camera", display_frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()