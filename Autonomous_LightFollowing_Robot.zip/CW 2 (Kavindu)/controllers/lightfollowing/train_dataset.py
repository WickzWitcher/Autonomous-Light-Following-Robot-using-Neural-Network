import numpy as np
import os

print("Neural Network Training Process")
print("-------------------------------")

# Dataset file path
dataset_path = "C:\Users\KAVINDU\OneDrive\Desktop\CW 2 (Kavindu)\controllers\lightfollowing\trained_model"

if not os.path.exists(dataset_path):
    print(f"Error: Dataset not found at {dataset_path}")
    exit()

# Load training data
data = np.load(dataset_path)
X = data['data']
y = data['labels']

print(f"Dataset loaded: {X.shape[0]} samples, {X.shape[1]} features")
print(f"Output classes: {y.shape[1]}")

def train_test_split(X, y, test_size=0.2, random_state=42):
    """Manual train-test split implementation"""
    np.random.seed(random_state)
    n_samples = X.shape[0]
    n_test = int(n_samples * test_size)
    
    # Shuffle dataset indices
    indices = np.random.permutation(n_samples)
    
    test_indices = indices[:n_test]
    train_indices = indices[n_test:]
    
    return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

print(f"Training samples: {X_train.shape[0]}")
print(f"Testing samples: {X_test.shape[0]}")

class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size):
        # Initialize network weights and biases
        self.weights1 = np.random.randn(input_size, hidden_size) * 0.1
        self.weights2 = np.random.randn(hidden_size, output_size) * 0.1
        self.bias1 = np.zeros((1, hidden_size))
        self.bias2 = np.zeros((1, output_size))
    
    def sigmoid(self, x):
        """Sigmoid activation function"""
        return 1 / (1 + np.exp(-np.clip(x, -10, 10)))
    
    def softmax(self, x):
        """Softmax activation for output layer"""
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    
    def forward(self, X):
        """Forward propagation through the network"""
        self.layer1 = self.sigmoid(np.dot(X, self.weights1) + self.bias1)
        self.output = self.softmax(np.dot(self.layer1, self.weights2) + self.bias2)
        return self.output
    
    def backward(self, X, y, learning_rate):
        """Backward propagation for weight updates"""
        m = X.shape[0]
        dZ2 = self.output - y
        dW2 = np.dot(self.layer1.T, dZ2) / m
        db2 = np.sum(dZ2, axis=0, keepdims=True) / m
        
        dZ1 = np.dot(dZ2, self.weights2.T) * (self.layer1 * (1 - self.layer1))
        dW1 = np.dot(X.T, dZ1) / m
        db1 = np.sum(dZ1, axis=0, keepdims=True) / m
        
        # Update weights and biases
        self.weights2 -= learning_rate * dW2
        self.bias2 -= learning_rate * db2
        self.weights1 -= learning_rate * dW1
        self.bias1 -= learning_rate * db1

# Initialize neural network
nn = NeuralNetwork(4, 8, 3)

print("Training neural network...")
for epoch in range(1000):
    output = nn.forward(X_train)
    loss = -np.mean(y_train * np.log(output + 1e-8))
    nn.backward(X_train, y_train, 0.1)
    
    if epoch % 100 == 0:
        # Evaluate on test set
        test_output = nn.forward(X_test)
        test_predictions = np.argmax(test_output, axis=1)
        test_labels = np.argmax(y_test, axis=1)
        test_accuracy = np.mean(test_predictions == test_labels)
        
        train_accuracy = np.mean(np.argmax(output, axis=1) == np.argmax(y_train, axis=1))
        print(f"Epoch {epoch}: Loss = {loss:.4f}, Train Acc = {train_accuracy:.4f}, Test Acc = {test_accuracy:.4f}")

# Final model evaluation
final_test_output = nn.forward(X_test)
final_predictions = np.argmax(final_test_output, axis=1)
true_test_labels = np.argmax(y_test, axis=1)
final_test_accuracy = np.mean(final_predictions == true_test_labels)

final_train_output = nn.forward(X_train)
final_train_predictions = np.argmax(final_train_output, axis=1)
true_train_labels = np.argmax(y_train, axis=1)
final_train_accuracy = np.mean(final_train_predictions == true_train_labels)

print("Training Results")
print("---------------")
print(f"Training Accuracy: {final_train_accuracy:.4f} ({final_train_accuracy*100:.2f}%)")
print(f"Test Accuracy: {final_test_accuracy:.4f} ({final_test_accuracy*100:.2f}%)")

if final_test_accuracy > 0.85:
    print("Model generalization: Excellent")
elif final_test_accuracy > 0.70:
    print("Model generalization: Good")
else:
    print("Model generalization: Needs improvement")

# Save trained model weights
weights_path = "C:\Users\KAVINDU\OneDrive\Desktop\CW 2 (Kavindu)\controllers\lightfollowing\trained_model"
np.savez(weights_path, 
         weights1=nn.weights1, 
         weights2=nn.weights2,
         bias1=nn.bias1,
         bias2=nn.bias2)

print(f"Model weights saved to: {weights_path}")
print("Training completed successfully")